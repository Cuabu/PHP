<?php
// Crear un archivo Excel
$filename = "ventas.xls";

header("Content-Type: application/vnd.ms-excel");
header("Content-Disposition: attachment; filename=\"$filename\"");

echo "<table style='border-collapse: collapse; width: 100%;'>";
echo "<thead>";
echo "<tr style='background-color: #f2f2f2;'>";
echo "<th style='border: 1px solid #dddddd; padding: 8px;'>Producto</th>";
echo "<th style='border: 1px solid #dddddd; padding: 8px;'>Cantidad</th>";
echo "<th style='border: 1px solid #dddddd; padding: 8px;'>Precio Unitario</th>";
echo "<th style='border: 1px solid #dddddd; padding: 8px;'>Total</th>";
echo "</tr>";
echo "</thead>";
echo "<tbody>";

$totalGeneral = 0;

if(isset($_POST['producto']) && isset($_POST['cantidad']) && isset($_POST['precio'])) {
    $productos = $_POST['producto'];
    $cantidades = $_POST['cantidad'];
    $precios = $_POST['precio'];

    for($i = 0; $i < count($productos); $i++) {
        $producto = $productos[$i];
        $cantidad = $cantidades[$i];
        $precio = $precios[$i];
        $total = $cantidad * $precio;
        $totalGeneral += $total;

        echo "<tr>";
        echo "<td style='border: 1px solid #dddddd; padding: 8px;'>$producto</td>";
        echo "<td style='border: 1px solid #dddddd; padding: 8px;'>$cantidad</td>";
        echo "<td style='border: 1px solid #dddddd; padding: 8px;'>$precio</td>";
        echo "<td style='border: 1px solid #dddddd; padding: 8px;'>$total</td>";
        echo "</tr>";
    }
}

echo "</tbody>";
echo "<tfoot>";
echo "<tr>";
echo "<td colspan='3' style='border: 1px solid #dddddd; padding: 8px; text-align: right;'><strong>Total General</strong></td>";
echo "<td style='border: 1px solid #dddddd; padding: 8px;'>$totalGeneral</td>";
echo "</tr>";
echo "</tfoot>";
echo "</table>";
?>
